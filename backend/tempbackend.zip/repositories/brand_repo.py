def fetch_brand_skus(conn):
    with conn.cursor() as cur:
        cur.execute("SELECT brand, sku, sku description FROM plan.dpr_gold_ibp ORDER BY brand, sku")
        return cur.fetchall()