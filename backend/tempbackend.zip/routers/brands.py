from fastapi import APIRouter, Depends
from schemas.brand import Brand
from db import get_connection


router = APIRouter()


@router.get("/brands", response_model=list[Brand])
def list_brands(conn=Depends(get_connection)):
    return brand_service.get_brands(conn)