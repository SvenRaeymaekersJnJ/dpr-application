from repositories import brand_repo

def get_brands(conn):
    brands: dict[str, list] = {}
    for brand, sku, desc in brand_repo.fetch_brand_skus(conn):
        brands.setdefault(brand, []).append({"sku": sku, "description": desc})
    return [{"brand": b, "skus": s} for b, s in brands.items()]